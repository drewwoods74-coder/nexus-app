import { useState, useEffect, useCallback } from "react";

const FONT = `@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&display=swap');
@keyframes shimmer{0%,100%{opacity:0}50%{opacity:1}}
@keyframes glow{0%,100%{opacity:.4}50%{opacity:1}}
@keyframes slidein{from{opacity:0;transform:translateX(-8px)}to{opacity:1;transform:translateX(0)}}
@keyframes popin{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
@keyframes xpfloat{0%{opacity:1;transform:translate(-50%,-50%) scale(1)}100%{opacity:0;transform:translate(-50%,-130%) scale(1.4)}}
@keyframes toastin{from{opacity:0;transform:translateX(-50%) translateY(-10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}`;

const SK="nexus_v1";
const C={bg:"#04070f",bg2:"#070c18",panel:"#0c1422",border:"rgba(0,210,255,0.13)",border2:"rgba(0,210,255,0.06)",cyan:"#00d2ff",teal:"#00ffcc",gold:"#ffc940",purple:"#a259ff",pink:"#ff2d78",green:"#00ff88",red:"#ff4444",text:"#bdd8ee",text2:"#5a7a9a",text3:"#2e4a62",fitness:"#ff7043",finance:"#ffc940",learning:"#a259ff",mindset:"#00ff88",relations:"#ff2d78"};
const catColor=k=>({fitness:C.fitness,finance:C.finance,learning:C.learning,mindset:C.mindset,relations:C.relations}[k]);
const catLabel=k=>({fitness:"FITNESS",finance:"FINANCE",learning:"LEARNING",mindset:"MINDSET",relations:"RELATIONS"}[k]);
const XP_TABLE=[0,200,500,1000,2000,3500,5500,8000,12000,18000,28000];
const TITLES=["INITIALIZATION","ACTIVATION","ASCENSION","AUGMENTATION","SPECIALIZATION","INTEGRATION","MASTERY","TRANSCENDENCE","APEX","GODMODE","OMNISCIENT"];
const CLASSES=["Recruit","Operative","Specialist","Strategist","Commander","Architect","Vanguard","Sovereign","Apex Agent","Godlike","Omniscient"];
const SEED=[{id:"s1",name:"Wake up early (before 7am)",category:"mindset",xp:5,streak:0},{id:"s2",name:"Make my bed",category:"mindset",xp:3,streak:0},{id:"s3",name:"Take vitamins",category:"fitness",xp:3,streak:0},{id:"s4",name:"Movement or exercise",category:"fitness",xp:10,streak:0},{id:"s5",name:"Read for 30 minutes",category:"learning",xp:7,streak:0},{id:"s6",name:"Gratitude journal or meditate",category:"mindset",xp:5,streak:0},{id:"s7",name:"Review budget or finances",category:"finance",xp:5,streak:0},{id:"s8",name:"Reach out to someone",category:"relations",xp:5,streak:0}];
const MISSIONS=[{id:"m1",tier:1,type:"auto",ul:1,name:"First Strike",desc:"Complete any habit today.",xp:50,goal:1,track:"dailyComplete"},{id:"m2",tier:1,type:"auto",ul:1,name:"Consistency Protocol",desc:"Maintain a 3-day streak.",xp:75,goal:3,track:"streak"},{id:"m3",tier:1,type:"pick",ul:1,name:"Emergency Reserve I",desc:"Log your first $100 in savings.",xp:80,goal:100,track:"savings"},{id:"m4",tier:1,type:"auto",ul:2,name:"Full System Boot",desc:"Add 5 directives to your list.",xp:60,goal:5,track:"habitCount"},{id:"m5",tier:1,type:"pick",ul:1,name:"Physical Activation",desc:"Log 3 workouts this week.",xp:75,goal:3,track:"wWorkouts"},{id:"m6",tier:1,type:"pick",ul:1,name:"Network Handshake",desc:"Log 5 connections this week.",xp:60,goal:5,track:"wConns"},{id:"m7",tier:2,type:"auto",ul:3,name:"7-Day Protocol",desc:"7 consecutive days of showing up.",xp:150,goal:7,track:"streak"},{id:"m8",tier:2,type:"pick",ul:3,name:"Capital Reserve I",desc:"Build savings to $500.",xp:175,goal:500,track:"savings"},{id:"m9",tier:2,type:"pick",ul:3,name:"Market Entry",desc:"Log your first $100 invested.",xp:150,goal:100,track:"invested"},{id:"m10",tier:2,type:"auto",ul:3,name:"500 XP Threshold",desc:"Accumulate 500 total XP.",xp:100,goal:500,track:"totalXP"},{id:"m11",tier:2,type:"pick",ul:3,name:"12-Workout Block",desc:"Log 12 total workouts.",xp:150,goal:12,track:"tWorkouts"},{id:"m12",tier:2,type:"pick",ul:2,name:"Debt Elimination I",desc:"Mark your first debt as paid off.",xp:200,goal:1,track:"debtsPaid"},{id:"m13",tier:3,type:"auto",ul:5,name:"2-Week Siege",desc:"14 days straight.",xp:300,goal:14,track:"streak"},{id:"m14",tier:3,type:"pick",ul:5,name:"Emergency Fund",desc:"$1,000 saved.",xp:350,goal:1000,track:"savings"},{id:"m15",tier:3,type:"pick",ul:5,name:"Portfolio Builder",desc:"$500 invested.",xp:375,goal:500,track:"invested"},{id:"m16",tier:3,type:"auto",ul:5,name:"2000 XP Singularity",desc:"2,000 total XP.",xp:250,goal:2000,track:"totalXP"},{id:"m17",tier:3,type:"pick",ul:4,name:"Relationship Capital",desc:"Log 20 total connections.",xp:275,goal:20,track:"tConns"},{id:"m18",tier:4,type:"auto",ul:7,name:"30-Day Metamorphosis",desc:"30 days without breaking.",xp:600,goal:30,track:"streak"},{id:"m19",tier:4,type:"pick",ul:7,name:"Freedom Fund",desc:"$5,000 saved.",xp:750,goal:5000,track:"savings"},{id:"m20",tier:4,type:"pick",ul:7,name:"Wealth Engine",desc:"$2,000 invested.",xp:800,goal:2000,track:"invested"},{id:"m21",tier:4,type:"auto",ul:8,name:"5000 XP Ascension",desc:"5,000 total XP.",xp:500,goal:5000,track:"totalXP"},{id:"m22",tier:4,type:"pick",ul:6,name:"50 Workouts",desc:"50 total workouts.",xp:550,goal:50,track:"tWorkouts"}];
const TUT=[{lbl:"STEP 01 // WELCOME",title:"Welcome to NEXUS",body:"You are Agent Drew. This is your Life Operating System — where daily habits become missions and consistency builds your character. Small actions, every day, compounding over time."},{lbl:"STEP 02 // DIRECTIVES",title:"Daily Habits = Small XP",body:"Directives earn 3-10 XP each. Making your bed is 3 XP. Movement is 10 XP. The compounding effect of showing up daily is where the real power is."},{lbl:"STEP 03 // MISSIONS",title:"Missions = Big Payouts",body:"Missions are major milestones — save $1,000, hit a 30-day streak, log 50 workouts. These pay 50-800 XP. Some auto-unlock as you level up. Others you choose."},{lbl:"STEP 04 // TRACKING",title:"Finance, Fitness & Relationships",body:"Three tabs track real-world progress. Finance tracks savings, investments, and debt. Fitness tracks workouts, steps, water, and sleep. Relations tracks calls, quality time, and networking."},{lbl:"STEP 05 // BEGIN",title:"Let's Go, Agent",body:"Your first mission is already active: complete one directive today. Every day you show up, your character evolves."}];

function getLvl(xp){for(let i=XP_TABLE.length-1;i>=0;i--)if(xp>=XP_TABLE[i])return i+1;return 1;}
function getLvlProg(xp){const l=getLvl(xp)-1,cur=XP_TABLE[l]||0,nxt=XP_TABLE[l+1];if(!nxt)return{pct:100,cur:xp,nxt:xp};return{pct:((xp-cur)/(nxt-cur))*100,cur:xp-cur,nxt:nxt-cur};}
function getWeekKey(){const d=new Date(),day=d.getDay(),diff=d.getDate()-day+(day===0?-6:1);return new Date(new Date().setDate(diff)).toDateString();}
function todayStr(){return new Date().toDateString();}
function defaultState(){const active=[];MISSIONS.forEach(m=>{if(m.type==="auto"&&m.ul<=1)active.push(m.id);});return{habits:[...SEED],totalXP:0,streak:0,lastActive:null,todayDone:{},lastReset:null,completedMissions:[],activeMissions:active,tutDone:false,fin:{savings:0,invested:0,debts:[],debtsPaid:0},fit:{workouts:0,tWorkouts:0,wKey:null,steps:0,water:0,sleep:null,stepsDate:null,waterDate:null},rel:{logs:[],wKey:null}};}
function loadState(){try{const r=localStorage.getItem(SK);if(r)return JSON.parse(r);}catch(e){}return defaultState();}
function saveState(s){try{localStorage.setItem(SK,JSON.stringify(s));}catch(e){}}

function Avatar({level}){
  const c=level>=7?C.gold:level>=4?C.purple:C.cyan;
  const helm=level>=5,wings=level>=8,crown=level>=10;
  return(<svg viewBox="0 0 64 72" fill="none" style={{width:60,height:68}}>
    <defs><radialGradient id="g1" cx="50%" cy="50%" r="50%"><stop offset="0%" stopColor={c} stopOpacity=".22"/><stop offset="100%" stopColor={c} stopOpacity="0"/></radialGradient></defs>
    <ellipse cx="32" cy="50" rx="17" ry="13" fill="url(#g1)"/>
    {wings&&<><path d="M14 42 L2 30 L10 44 Z" fill={c} opacity=".45"/><path d="M50 42 L62 30 L54 44 Z" fill={c} opacity=".45"/></>}
    <rect x="20" y="44" width="24" height="20" rx="2" fill="#0c1828" stroke={c} strokeWidth="1"/>
    <rect x="24" y="48" width="16" height="8" rx="1" fill={c} opacity=".1"/>
    <rect x="14" y="44" width="8" height="10" rx="1" fill="#0c1828" stroke={c} strokeWidth=".9"/>
    <rect x="42" y="44" width="8" height="10" rx="1" fill="#0c1828" stroke={c} strokeWidth=".9"/>
    <rect x="16" y="54" width="6" height="10" rx="1" fill="#080e1c" stroke={c} strokeWidth=".7" opacity=".8"/>
    <rect x="42" y="54" width="6" height="10" rx="1" fill="#080e1c" stroke={c} strokeWidth=".7" opacity=".8"/>
    <rect x="29" y="38" width="6" height="8" fill="#080e1c" stroke={c} strokeWidth=".5" opacity=".7"/>
    {helm?<><rect x="20" y="14" width="24" height="18" rx="3" fill="#080e1c" stroke={c} strokeWidth="1.1"/><rect x="22" y="20" width="20" height="8" rx="2" fill={c} opacity=".16"/><rect x="22" y="10" width="20" height="6" rx="2" fill="#0a1520" stroke={c} strokeWidth=".9"/>{crown?<><polygon points="32,4 28,10 36,10" fill={c} opacity=".8"/><circle cx="32" cy="4" r="2" fill={c}/></>:<line x1="28" y1="10" x2="36" y2="10" stroke={c} strokeWidth="1.4"/>}<rect x="18" y="16" width="4" height="8" rx="1" fill="#0a1520" stroke={c} strokeWidth=".7"/><rect x="42" y="16" width="4" height="8" rx="1" fill="#0a1520" stroke={c} strokeWidth=".7"/></>:<><ellipse cx="32" cy="24" rx="11" ry="13" fill="#0d1a2e" stroke={c} strokeWidth=".9"/><ellipse cx="28" cy="22" rx="2.4" ry="1.9" fill={c} opacity=".55"/><ellipse cx="36" cy="22" rx="2.4" ry="1.9" fill={c} opacity=".55"/><ellipse cx="28" cy="22" rx="1.4" ry="1.1" fill={c}/><ellipse cx="36" cy="22" rx="1.4" ry="1.1" fill={c}/><line x1="29" y1="30" x2="35" y2="30" stroke={c} strokeWidth=".9" opacity=".35"/></>}
    <circle cx="32" cy="52" r="2.8" fill={c} opacity=".35"/><circle cx="32" cy="52" r="1.4" fill={c} opacity=".85"/>
    {Array.from({length:Math.min(level,5)},(_,i)=><circle key={i} cx={21+i*5.5} cy="67" r="1.4" fill={c} opacity=".65"/>)}
  </svg>);
}

export default function App(){
  const [S,setS]=useState(loadState);
  const [page,setPage]=useState("hq");
  const [tutStep,setTutStep]=useState(0);
  const [toast,setToast]=useState(null);
  const [xpPop,setXpPop]=useState(false);
  const [modal,setModal]=useState(false);
  const [nh,setNh]=useState({name:"",category:"",xp:5});

  useEffect(()=>{saveState(S);},[S]);

  useEffect(()=>{
    const today=todayStr(),wk=getWeekKey();
    setS(prev=>{
      if(prev.lastReset===today)return prev;
      let next={...prev};
      if(prev.lastActive){const diff=Math.round((new Date()-new Date(prev.lastActive))/86400000);const anyDone=Object.values(prev.todayDone||{}).some(Boolean);if(diff===1&&anyDone)next.streak=(prev.streak||0)+1;else if(diff>1)next.streak=0;}
      next.todayDone={};next.lastReset=today;
      if(prev.fit.stepsDate!==today)next.fit={...next.fit,steps:0,water:0,stepsDate:today,waterDate:today};
      if(prev.fit.wKey!==wk)next.fit={...next.fit,workouts:0,wKey:wk};
      return next;
    });
  },[]);

  const lvl=getLvl(S.totalXP);
  const prog=getLvlProg(S.totalXP);
  const doneCount=Object.values(S.todayDone).filter(Boolean).length;
  const wk=getWeekKey();

  const showToast=useCallback((title,sub)=>{setToast({title,sub});setTimeout(()=>setToast(null),2800);},[]);
  const popXP=useCallback(()=>{setXpPop(true);setTimeout(()=>setXpPop(false),1200);},[]);

  function getMProg(m,state){
    switch(m.track){
      case"dailyComplete":return Math.min(Object.values(state.todayDone).filter(Boolean).length,m.goal);
      case"streak":return Math.min(state.streak||0,m.goal);
      case"savings":return Math.min(state.fin.savings||0,m.goal);
      case"invested":return Math.min(state.fin.invested||0,m.goal);
      case"totalXP":return Math.min(state.totalXP||0,m.goal);
      case"habitCount":return Math.min(state.habits.length,m.goal);
      case"wWorkouts":return Math.min(state.fit.workouts||0,m.goal);
      case"tWorkouts":return Math.min(state.fit.tWorkouts||0,m.goal);
      case"wConns":return Math.min((state.rel.logs||[]).filter(l=>l.wk===wk).length,m.goal);
      case"tConns":return Math.min((state.rel.logs||[]).length,m.goal);
      case"debtsPaid":return Math.min(state.fin.debtsPaid||0,m.goal);
      default:return 0;
    }
  }

  function autoUnlock(state){const lv=getLvl(state.totalXP);const next=[...state.activeMissions];MISSIONS.forEach(m=>{if(m.type!=="auto")return;if(state.completedMissions.includes(m.id))return;if(!next.includes(m.id)&&lv>=m.ul)next.push(m.id);});return next;}

  function checkComplete(state){
    let s={...state};
    state.activeMissions.forEach(id=>{
      if(s.completedMissions.includes(id))return;
      const m=MISSIONS.find(x=>x.id===id);if(!m)return;
      if(getMProg(m,s)>=m.goal){s={...s,completedMissions:[...s.completedMissions,id],totalXP:s.totalXP+m.xp};setTimeout(()=>showToast("MISSION COMPLETE",`${m.name} — +${m.xp} XP`),600);}
    });
    s.activeMissions=autoUnlock(s);return s;
  }

  function toggleHabit(id){
    setS(prev=>{
      const h=prev.habits.find(x=>x.id===id);if(!h)return prev;
      const was=!!prev.todayDone[id];
      if(!was){
        const next={...prev,todayDone:{...prev.todayDone,[id]:true},totalXP:prev.totalXP+h.xp,habits:prev.habits.map(x=>x.id===id?{...x,streak:(x.streak||0)+1}:x),lastActive:todayStr()};
        const oldLvl=getLvl(prev.totalXP),newLvl=getLvl(next.totalXP);
        if(newLvl>oldLvl)setTimeout(()=>showToast(`LEVEL UP — LVL ${newLvl}`,TITLES[Math.min(newLvl-1,TITLES.length-1)]),100);
        else setTimeout(()=>showToast("DIRECTIVE COMPLETE",`+${h.xp} XP acquired`),100);
        popXP();next.activeMissions=autoUnlock(next);return checkComplete(next);
      }else{
        return{...prev,todayDone:{...prev.todayDone,[id]:false},totalXP:Math.max(0,prev.totalXP-h.xp),habits:prev.habits.map(x=>x.id===id?{...x,streak:Math.max(0,(x.streak||1)-1)}:x)};
      }
    });
  }

  function deleteHabit(id){if(!window.confirm("Remove this directive?"))return;setS(prev=>{const td={...prev.todayDone};delete td[id];return{...prev,habits:prev.habits.filter(h=>h.id!==id),todayDone:td}});}

  function addHabit(){
    if(!nh.name.trim()||!nh.category)return;
    const h={id:Date.now().toString(36),name:nh.name.trim(),category:nh.category,xp:nh.xp,streak:0};
    setS(prev=>{const n={...prev,habits:[...prev.habits,h]};n.activeMissions=autoUnlock(n);return checkComplete(n);});
    setModal(false);setNh({name:"",category:"",xp:5});showToast("DIRECTIVE DEPLOYED",`"${h.name}" active`);
  }

  function activateMission(id){setS(prev=>({...prev,activeMissions:prev.activeMissions.includes(id)?prev.activeMissions:[...prev.activeMissions,id]}));showToast("MISSION ACCEPTED",MISSIONS.find(x=>x.id===id)?.name||"");}
  function finishTut(){setS(prev=>{const n={...prev,tutDone:true};n.activeMissions=autoUnlock(n);return n;});}

  function addSavings(v){if(!v||v<=0)return;setS(prev=>{const n={...prev,fin:{...prev.fin,savings:(prev.fin.savings||0)+v}};n.activeMissions=autoUnlock(n);popXP();showToast("SAVINGS LOGGED",`+$${v}`);return checkComplete(n);});}
  function addInvest(v){if(!v||v<=0)return;setS(prev=>{const n={...prev,fin:{...prev.fin,invested:(prev.fin.invested||0)+v}};n.activeMissions=autoUnlock(n);popXP();showToast("INVESTMENT LOGGED",`+$${v}`);return checkComplete(n);});}
  function addDebt(name,amt){if(!name||!amt)return;setS(prev=>({...prev,fin:{...prev.fin,debts:[...(prev.fin.debts||[]),{name,amount:amt}]}}));}
  function payDebt(i){if(!window.confirm("Mark as paid off?"))return;setS(prev=>{const debts=prev.fin.debts.filter((_,idx)=>idx!==i);const n={...prev,fin:{...prev.fin,debts,debtsPaid:(prev.fin.debtsPaid||0)+1},totalXP:prev.totalXP+30};popXP();showToast("DEBT ELIMINATED","+30 XP");n.activeMissions=autoUnlock(n);return checkComplete(n);});}
  function delDebt(i){setS(prev=>({...prev,fin:{...prev.fin,debts:prev.fin.debts.filter((_,idx)=>idx!==i)}}));}
  function logWorkout(){setS(prev=>{const n={...prev,fit:{...prev.fit,workouts:(prev.fit.workouts||0)+1,tWorkouts:(prev.fit.tWorkouts||0)+1},totalXP:prev.totalXP+15};popXP();showToast("WORKOUT LOGGED","+15 XP");n.activeMissions=autoUnlock(n);return checkComplete(n);});}
  function logSteps(v){if(!v)return;setS(prev=>{const ns=(prev.fit.steps||0)+v,bonus=ns>=8000&&(prev.fit.steps||0)<8000;const n={...prev,fit:{...prev.fit,steps:ns},totalXP:prev.totalXP+(bonus?10:0)};if(bonus)showToast("STEP GOAL HIT","+10 XP");return n;});}
  function addWater(){setS(prev=>{const nw=(prev.fit.water||0)+8,bonus=nw>=80&&(prev.fit.water||0)<80;const n={...prev,fit:{...prev.fit,water:nw},totalXP:prev.totalXP+(bonus?5:0)};if(bonus)showToast("HYDRATION GOAL","+5 XP");return n;});}
  function logSleep(v){if(!v)return;setS(prev=>{const bonus=v>=7&&v<=9;const n={...prev,fit:{...prev.fit,sleep:v},totalXP:prev.totalXP+(bonus?5:0)};if(bonus)showToast("OPTIMAL SLEEP","+5 XP");return n;});}
  function logConn(name,type){if(!name.trim())return;setS(prev=>{const n={...prev,rel:{...prev.rel,logs:[...(prev.rel.logs||[]),{name:name.trim(),type,date:new Date().toLocaleDateString("en-US",{month:"short",day:"numeric"}),wk}]},totalXP:prev.totalXP+5};popXP();showToast("CONNECTION LOGGED",`+5 XP`);n.activeMissions=autoUnlock(n);return checkComplete(n);});}
  function delRel(i){setS(prev=>({...prev,rel:{...prev.rel,logs:prev.rel.logs.filter((_,idx)=>idx!==i)}}));}

  const mono={fontFamily:"'Share Tech Mono',monospace"};
  const orb={fontFamily:"'Orbitron',monospace"};
  const raj={fontFamily:"'Rajdhani',sans-serif"};
  const inpS={background:"rgba(0,210,255,0.03)",border:`1px solid ${C.border}`,color:C.text,padding:"7px 10px",...raj,fontSize:13,outline:"none",width:"100%"};
  const btnS={...mono,fontSize:9,letterSpacing:2,color:C.cyan,background:"transparent",border:`1px solid ${C.border}`,padding:"5px 11px",cursor:"pointer"};

  function SecHdr({title,right,color}){return(<div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:11}}><div style={{...orb,fontSize:9,fontWeight:700,letterSpacing:4,color:color||C.text2,display:"flex",alignItems:"center",gap:9}}><div style={{width:12,height:2,background:color||C.cyan}}/>{title}</div>{right}</div>);}

  function CatBar({cat,icon}){
    const habits=S.habits.filter(h=>h.category===cat);
    const done=habits.filter(h=>S.todayDone[h.id]).length;
    const pct=habits.length===0?0:Math.round((done/habits.length)*100);
    const col=catColor(cat);
    return(<div style={{background:C.panel,border:`1px solid ${C.border2}`,padding:"9px 11px"}}><div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}><span style={{...mono,fontSize:8,letterSpacing:2,color:col}}>{icon} {cat.slice(0,3).toUpperCase()}</span><span style={{...orb,fontSize:11,fontWeight:700,color:col}}>{pct}%</span></div><div style={{height:3,background:"rgba(255,255,255,0.04)"}}><div style={{height:"100%",width:`${pct}%`,background:col,transition:"width .6s"}}/></div></div>);
  }

  function HabitRow({h}){
    const done=!!S.todayDone[h.id];
    const col=catColor(h.category);
    const [hov,setHov]=useState(false);
    return(
      <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
        style={{background:done?"rgba(0,255,136,0.015)":C.panel,border:`1px solid ${hov?C.border:C.border2}`,borderLeft:`3px solid ${col}`,padding:"11px 13px",display:"flex",alignItems:"center",gap:11,opacity:done?.45:1,marginBottom:6,transition:"opacity .2s,border-color .2s"}}>
        <button onClick={()=>toggleHabit(h.id)}
          style={{width:26,height:26,borderRadius:"50%",border:`2px solid ${done?C.green:C.border}`,background:done?"rgba(0,255,136,0.09)":"transparent",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,color:done?C.green:"transparent",flexShrink:0,transition:"all .2s",outline:"none"}}>✓</button>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:14,fontWeight:600,color:done?C.text3:C.text,textDecoration:done?"line-through":"none",marginBottom:2}}>{h.name}</div>
          <div style={{display:"flex",gap:7,...mono,fontSize:8,color:C.text3}}>
            <span style={{background:`${col}22`,color:col,padding:"1px 5px",fontSize:7,letterSpacing:1}}>{catLabel(h.category)}</span>
            <span>🔥 {h.streak||0}d</span>
          </div>
        </div>
        <div style={{...orb,fontSize:10,fontWeight:700,color:col,marginLeft:"auto",whiteSpace:"nowrap"}}>+{h.xp} XP</div>
        {hov&&<button onClick={()=>deleteHabit(h.id)} style={{background:"transparent",border:"none",color:C.text3,cursor:"pointer",fontSize:11,padding:"0 4px",outline:"none"}}>✕</button>}
      </div>
    );
  }

  function MissionCard({m}){
    const tc={1:C.cyan,2:C.purple,3:C.gold,4:C.pink}[m.tier];
    const done=S.completedMissions.includes(m.id);
    const active=S.activeMissions.includes(m.id);
    const unlocked=getLvl(S.totalXP)>=m.ul;
    const pg=getMProg(m,S);
    const pct=Math.min((pg/m.goal)*100,100);
    const canPick=!active&&!done&&unlocked&&m.type==="pick";
    return(<div style={{background:C.panel,border:`1px solid ${done?"rgba(0,255,136,0.18)":active?C.border:C.border2}`,padding:"13px 15px",opacity:!unlocked?.3:1,marginBottom:7,position:"relative"}}>
      {!unlocked&&<div style={{position:"absolute",top:"50%",right:13,transform:"translateY(-50%)",...mono,fontSize:8,color:C.text3,letterSpacing:3}}>LOCKED</div>}
      <div style={{display:"flex",gap:10,marginBottom:6}}>
        <div style={{flex:1}}>
          <div style={{...mono,fontSize:7,letterSpacing:3,color:tc,marginBottom:3}}>{m.type==="auto"?"AUTO-MISSION":"CHOOSE THIS MISSION"}</div>
          <div style={{fontSize:14,fontWeight:700,color:"#fff",marginBottom:2}}>{m.name}</div>
          <div style={{fontSize:12,color:C.text2,lineHeight:1.5}}>{m.desc}</div>
        </div>
        <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4,flexShrink:0}}>
          <div style={{...orb,fontSize:14,fontWeight:700,color:C.gold}}>+{m.xp} XP</div>
          <div style={{...mono,fontSize:7,letterSpacing:2,padding:"2px 6px",background:done?"rgba(0,255,136,.13)":unlocked?"rgba(0,210,255,.07)":"rgba(255,255,255,.03)",color:done?C.green:unlocked?C.cyan:C.text3}}>{done?"DONE":unlocked?"UNLOCKED":`LVL ${m.ul}`}</div>
        </div>
      </div>
      {(active||done)&&<div style={{marginTop:8}}><div style={{display:"flex",justifyContent:"space-between",...mono,fontSize:8,color:C.text3,marginBottom:4}}><span>PROGRESS</span><span>{pg} / {m.goal}</span></div><div style={{height:3,background:"rgba(255,255,255,0.04)"}}><div style={{height:"100%",width:`${pct}%`,background:`linear-gradient(90deg,${C.cyan},${C.teal})`,transition:"width .7s"}}/></div></div>}
      {canPick&&<div style={{marginTop:10}}><button onClick={()=>activateMission(m.id)} style={{...btnS,borderColor:C.cyan,background:"rgba(0,210,255,0.07)"}}>ACCEPT MISSION</button></div>}
    </div>);
  }

  function FinCard({title,val,target,color,onAdd}){
    const [v,setV]=useState("");
    const pct=Math.min((val/target)*100,100);
    return(<div style={{background:C.panel,border:`1px solid ${C.border2}`,padding:14}}><div style={{...mono,fontSize:8,letterSpacing:3,color:C.text3,marginBottom:7}}>{title}</div><div style={{...orb,fontSize:20,fontWeight:700,color:C.gold,marginBottom:2}}>${val.toLocaleString()}</div><div style={{...mono,fontSize:8,color:C.text3,marginBottom:7}}>TARGET: ${target.toLocaleString()}</div><div style={{height:3,background:"rgba(255,255,255,0.04)",marginBottom:10}}><div style={{height:"100%",width:`${pct}%`,background:color,transition:"width .6s"}}/></div><div style={{display:"flex",gap:7}}><input type="number" value={v} onChange={e=>setV(e.target.value)} placeholder="Add $..." min="0" style={{...inpS,flex:1}}/><button onClick={()=>{onAdd(parseFloat(v));setV("");}} style={btnS}>LOG</button></div></div>);
  }

  function HQ(){
    const sorted=[...S.habits].sort((a,b)=>(S.todayDone[a.id]?1:0)-(S.todayDone[b.id]?1:0));
    const ac=lvl>=7?C.gold:lvl>=4?C.purple:C.cyan;
    const corners=[{top:0,left:0,borderWidth:"2px 0 0 2px"},{top:0,right:0,borderWidth:"2px 2px 0 0"},{bottom:0,left:0,borderWidth:"0 0 2px 2px"},{bottom:0,right:0,borderWidth:"0 2px 2px 0"}];
    return(<div>
      <div style={{background:C.panel,border:`1px solid ${C.border}`,position:"relative",overflow:"hidden",padding:"16px 18px",marginBottom:16}}>
        <div style={{position:"absolute",top:0,left:0,right:0,height:1,background:`linear-gradient(90deg,transparent,${C.cyan},transparent)`}}/>
        <div style={{position:"absolute",top:8,right:12,...mono,fontSize:7,color:C.text3,letterSpacing:3}}>AGENT PROFILE</div>
        <div style={{display:"flex",gap:16,alignItems:"center"}}>
          <div style={{flexShrink:0,position:"relative",width:86}}>
            <div style={{width:86,height:86,border:`1px solid ${ac}`,background:"linear-gradient(160deg,rgba(0,210,255,0.07),rgba(162,89,255,0.07))",display:"flex",alignItems:"center",justifyContent:"center",position:"relative",overflow:"hidden",boxShadow:`0 0 24px rgba(0,210,255,0.12)`}}>
              <div style={{position:"absolute",inset:0,backgroundImage:"repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,210,255,0.022) 3px,rgba(0,210,255,0.022) 4px)",pointerEvents:"none"}}/>
              {corners.map((pos,i)=><div key={i} style={{position:"absolute",width:7,height:7,borderColor:ac,borderStyle:"solid",...pos}}/>)}
              <Avatar level={lvl}/>
              <div style={{position:"absolute",bottom:-8,left:"50%",transform:"translateX(-50%)",width:54,height:14,background:"rgba(0,210,255,0.2)",filter:"blur(8px)",animation:"glow 3s ease-in-out infinite"}}/>
            </div>
            <div style={{position:"absolute",bottom:-8,left:"50%",transform:"translateX(-50%)",background:ac,color:C.bg,...orb,fontSize:7,fontWeight:700,padding:"2px 7px",letterSpacing:1,whiteSpace:"nowrap",zIndex:2}}>LVL {lvl}</div>
          </div>
          <div style={{flex:1,display:"flex",flexDirection:"column",gap:6}}>
            <div><div style={{...orb,fontSize:14,fontWeight:700,color:"#fff",letterSpacing:2}}>AGENT DREW</div><div style={{...mono,fontSize:9,color:C.cyan,letterSpacing:2}}>// {TITLES[Math.min(lvl-1,TITLES.length-1)]}</div><div style={{...mono,fontSize:8,color:C.text3}}>Class: {CLASSES[Math.min(lvl-1,CLASSES.length-1)]}</div></div>
            <div><div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{...mono,fontSize:8,color:C.text3,letterSpacing:2}}>XP PROGRESS</span><span style={{...orb,fontSize:10,color:C.cyan}}>{prog.cur} / {prog.nxt}</span></div><div style={{height:5,background:"rgba(0,210,255,0.06)",border:`1px solid ${C.border2}`,overflow:"hidden"}}><div style={{height:"100%",width:`${prog.pct}%`,background:`linear-gradient(90deg,${C.cyan},${C.teal})`,transition:"width .9s"}}/>
            </div></div>
            <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
              {[[S.totalXP,"⚡","XP"],[S.streak||0,"🔥","STREAK"],[doneCount,"✓","TODAY"],[S.completedMissions.length,"🎯","DONE"]].map(([v,i,l])=>(<div key={l} style={{display:"flex",alignItems:"center",gap:4,background:"rgba(0,210,255,0.04)",border:`1px solid ${C.border2}`,padding:"4px 8px"}}><span style={{fontSize:11}}>{i}</span><div><div style={{...orb,fontSize:12,color:C.cyan}}>{v}</div><div style={{...mono,fontSize:7,color:C.text3,letterSpacing:2}}>{l}</div></div></div>))}
            </div>
          </div>
        </div>
      </div>
      <SecHdr title="SYSTEM STATUS"/>
      <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:7,marginBottom:16}}>
        {[["fitness","⚡"],["finance","◈"],["learning","◉"],["mindset","✦"],["relations","♡"]].map(([c,i])=><CatBar key={c} cat={c} icon={i}/>)}
      </div>
      <SecHdr title="ACTIVE DIRECTIVES" right={<button style={btnS} onClick={()=>setModal(true)}>+ NEW</button>}/>
      {sorted.length===0?<div style={{textAlign:"center",padding:28,border:`1px dashed ${C.border2}`,...mono,fontSize:9,color:C.text3,letterSpacing:2,lineHeight:2.2}}>NO DIRECTIVES ACTIVE<br/>TAP + NEW TO INITIALIZE</div>:sorted.map(h=><HabitRow key={h.id} h={h}/>)}
    </div>);
  }

  function MissionsPage(){
    const tc={1:C.cyan,2:C.purple,3:C.gold,4:C.pink};
    const tl={1:"TIER 1 // RECRUIT",2:"TIER 2 // OPERATIVE",3:"TIER 3 // SPECIALIST",4:"TIER 4 // COMMANDER"};
    return(<div><SecHdr title="MISSION BOARD" right={<div style={{...mono,fontSize:8,letterSpacing:2,color:C.bg,background:C.cyan,padding:"2px 7px"}}>{S.activeMissions.length} ACTIVE</div>}/>{[1,2,3,4].map(t=>(<div key={t} style={{marginTop:t>1?16:0}}><SecHdr title={tl[t]} color={tc[t]}/>{MISSIONS.filter(m=>m.tier===t).map(m=><MissionCard key={m.id} m={m}/>)}</div>))}</div>);
  }

  function FinancePage(){
    const [dn,setDn]=useState("");const [da,setDa]=useState("");
    return(<div><SecHdr title="FINANCIAL COMMAND"/><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}><FinCard title="SAVINGS BALANCE" val={S.fin.savings||0} target={1000} color={C.gold} onAdd={addSavings}/><FinCard title="INVESTMENTS" val={S.fin.invested||0} target={500} color={C.purple} onAdd={addInvest}/></div><SecHdr title="DEBT TRACKER"/><div style={{display:"flex",gap:7,marginBottom:10}}><input placeholder="Debt name..." value={dn} onChange={e=>setDn(e.target.value)} style={{...inpS,flex:2}}/><input type="number" placeholder="Amount..." value={da} onChange={e=>setDa(e.target.value)} style={{...inpS,flex:1}}/><button onClick={()=>{addDebt(dn,parseFloat(da));setDn("");setDa("");}} style={btnS}>+ ADD</button></div>{(S.fin.debts||[]).length===0?<div style={{textAlign:"center",padding:16,border:`1px dashed ${C.border2}`,...mono,fontSize:9,color:C.text3,letterSpacing:2}}>NO DEBTS LOGGED</div>:(S.fin.debts||[]).map((d,i)=>(<div key={i} style={{background:C.panel,border:`1px solid ${C.border2}`,padding:"10px 13px",display:"flex",alignItems:"center",gap:9,marginBottom:6}}><div style={{flex:1,fontSize:13,fontWeight:600,color:C.text}}>{d.name}</div><div style={{...orb,fontSize:11,color:C.red}}>${Number(d.amount).toLocaleString()}</div><button onClick={()=>payDebt(i)} style={{...mono,fontSize:7,letterSpacing:1,color:C.green,background:"rgba(0,255,136,.06)",border:`1px solid rgba(0,255,136,.2)`,padding:"3px 7px",cursor:"pointer"}}>PAID OFF</button><button onClick={()=>delDebt(i)} style={{background:"transparent",border:"none",color:C.text3,cursor:"pointer",fontSize:11,outline:"none"}}>✕</button></div>))}</div>);
  }

  function FitnessPage(){
    const [si,setSi]=useState("");const [sl,setSl]=useState("");
    const f=S.fit;
    function FCard({title,val,goal,color,children}){const pct=goal?Math.min((Number(val)/goal)*100,100):0;return(<div style={{background:C.panel,border:`1px solid ${C.border2}`,padding:13}}><div style={{...mono,fontSize:8,letterSpacing:3,color:C.text3,marginBottom:7}}>{title}</div><div style={{...orb,fontSize:20,fontWeight:700,color:color||C.fitness,marginBottom:2}}>{typeof val==="number"?val.toLocaleString():val}</div>{goal&&<><div style={{...mono,fontSize:8,color:C.text3,marginBottom:6}}>GOAL: {goal.toLocaleString()}</div><div style={{height:3,background:"rgba(255,255,255,0.04)",marginBottom:10}}><div style={{height:"100%",width:`${pct}%`,background:color||C.fitness,transition:"width .6s"}}/></div></>}{children}</div>);}
    return(<div><SecHdr title="FITNESS COMMAND"/><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}><FCard title="WORKOUTS THIS WEEK" val={f.workouts||0} goal={4} color={C.fitness}><button onClick={logWorkout} style={{...btnS,width:"100%",textAlign:"center"}}>+ LOG WORKOUT</button></FCard><FCard title="STEPS TODAY" val={f.steps||0} goal={8000} color={C.fitness}><div style={{display:"flex",gap:7}}><input type="number" placeholder="Steps..." value={si} onChange={e=>setSi(e.target.value)} style={{...inpS,flex:1}}/><button onClick={()=>{logSteps(parseInt(si));setSi("");}} style={btnS}>LOG</button></div></FCard><FCard title="WATER TODAY (OZ)" val={f.water||0} goal={80} color={C.cyan}><button onClick={addWater} style={{...btnS,width:"100%",textAlign:"center"}}>+ 8 OZ</button></FCard><FCard title="SLEEP LAST NIGHT" val={f.sleep||"--"} goal={9} color={C.purple}><div style={{display:"flex",gap:7}}><input type="number" placeholder="Hours..." value={sl} onChange={e=>setSl(e.target.value)} min="0" max="24" step="0.5" style={{...inpS,flex:1}}/><button onClick={()=>{logSleep(parseFloat(sl));setSl("");}} style={btnS}>LOG</button></div></FCard></div></div>);
  }

  function RelationsPage(){
    const [rn,setRn]=useState("");const [rt,setRt]=useState("call");
    const logs=S.rel.logs||[];
    const thisWeek=logs.filter(l=>l.wk===wk);
    const net=logs.filter(l=>l.type==="network");
    const tl={call:"CALL/TEXT",quality:"QUALITY TIME",network:"NETWORKING",date:"DATE NIGHT"};
    return(<div><SecHdr title="RELATIONSHIP COMMAND"/><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>{[[thisWeek.length,"CONNECTIONS THIS WEEK","calls, texts, meetups"],[net.length,"NETWORKING THIS MONTH","professional connections"]].map(([v,t,sub])=>(<div key={t} style={{background:C.panel,border:`1px solid ${C.border2}`,padding:13}}><div style={{...mono,fontSize:8,letterSpacing:3,color:C.text3,marginBottom:7}}>{t}</div><div style={{...orb,fontSize:20,fontWeight:700,color:C.relations,marginBottom:2}}>{v}</div><div style={{...mono,fontSize:8,color:C.text3}}>{sub}</div></div>))}</div><SecHdr title="LOG A CONNECTION"/><div style={{display:"flex",gap:7,marginBottom:10,flexWrap:"wrap"}}><input placeholder="Name..." value={rn} onChange={e=>setRn(e.target.value)} style={{...inpS,flex:2,minWidth:100}}/><select value={rt} onChange={e=>setRt(e.target.value)} style={{...inpS,flex:1,minWidth:100,cursor:"pointer"}}><option value="call">Call / Text</option><option value="quality">Quality Time</option><option value="network">Networking</option><option value="date">Date Night</option></select><button onClick={()=>{logConn(rn,rt);setRn("");}} style={btnS}>+ LOG</button></div>{logs.length===0?<div style={{textAlign:"center",padding:16,border:`1px dashed ${C.border2}`,...mono,fontSize:9,color:C.text3,letterSpacing:2}}>NO CONNECTIONS LOGGED YET</div>:[...logs].reverse().slice(0,20).map((l,i)=>(<div key={i} style={{background:C.panel,border:`1px solid ${C.border2}`,borderLeft:`3px solid ${C.relations}`,padding:"9px 12px",display:"flex",alignItems:"center",gap:8,marginBottom:5}}><div style={{flex:1,fontSize:13,fontWeight:600,color:C.text}}>{l.name}</div><div style={{...mono,fontSize:7,color:C.relations,background:"rgba(255,45,120,.1)",padding:"2px 5px",letterSpacing:1}}>{tl[l.type]}</div><div style={{...mono,fontSize:7,color:C.text3}}>{l.date}</div><button onClick={()=>delRel(logs.length-1-i)} style={{background:"transparent",border:"none",color:C.text3,cursor:"pointer",fontSize:10,outline:"none"}}>✕</button></div>))}</div>);
  }

  const pages={hq:<HQ/>,missions:<MissionsPage/>,finance:<FinancePage/>,fitness:<FitnessPage/>,relations:<RelationsPage/>};

  return(<div style={{...raj,background:C.bg,minHeight:"100vh",color:C.text,position:"relative",overflow:"hidden"}}>
    <style>{FONT}</style>
    <div style={{position:"fixed",inset:0,backgroundImage:`linear-gradient(rgba(0,210,255,0.022) 1px,transparent 1px),linear-gradient(90deg,rgba(0,210,255,0.022) 1px,transparent 1px)`,backgroundSize:"48px 48px",pointerEvents:"none",zIndex:0}}/>
    <div style={{position:"fixed",inset:0,background:`radial-gradient(ellipse 60% 40% at 20% 10%,rgba(0,210,255,0.04) 0%,transparent 60%),radial-gradient(ellipse 40% 60% at 80% 90%,rgba(162,89,255,0.035) 0%,transparent 60%)`,pointerEvents:"none",zIndex:0}}/>
    <header style={{position:"relative",zIndex:20,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 18px",borderBottom:`1px solid ${C.border}`,background:"rgba(4,7,15,0.95)",backdropFilter:"blur(20px)"}}>
      <div style={{...orb,fontSize:14,fontWeight:900,letterSpacing:5,color:C.cyan,textShadow:`0 0 20px rgba(0,210,255,0.4)`}}>NEXUS<span style={{display:"block",...mono,fontSize:7,letterSpacing:5,color:C.text3,fontWeight:400,marginTop:2}}>LIFE OPERATING SYSTEM</span></div>
      <div style={{display:"flex",alignItems:"center",gap:12}}>
        <nav style={{display:"flex",gap:2}}>{[["hq","HQ"],["missions","MISSIONS"],["finance","FINANCE"],["fitness","FITNESS"],["relations","RELATIONS"]].map(([p,l])=>(<button key={p} onClick={()=>setPage(p)} style={{...mono,fontSize:8,letterSpacing:2,color:page===p?C.cyan:C.text3,background:page===p?"rgba(0,210,255,0.06)":"transparent",border:`1px solid ${page===p?C.border:"transparent"}`,borderBottom:page===p?`1px solid ${C.cyan}`:"1px solid transparent",padding:"5px 10px",cursor:"pointer",outline:"none"}}>{l}</button>))}</nav>
        <div style={{...mono,fontSize:8,color:C.text3,textAlign:"right",lineHeight:1.8}}><div style={{color:C.text2,fontSize:10}}>{new Date().toLocaleDateString("en-US",{weekday:"long"}).toUpperCase()}</div><div>{new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}).toUpperCase()}</div></div>
      </div>
    </header>
    <main style={{position:"relative",zIndex:10,maxWidth:940,margin:"0 auto",padding:"18px 14px 80px"}}>{pages[page]}</main>
    {!S.tutDone&&(<div style={{position:"fixed",inset:0,background:"rgba(4,7,15,0.93)",backdropFilter:"blur(8px)",zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
      <div style={{background:C.bg2,border:`1px solid ${C.cyan}`,maxWidth:440,width:"100%",position:"relative"}}>
        <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,${C.cyan},${C.purple})`}}/>
        <div style={{padding:"28px 24px"}}><div style={{...mono,fontSize:8,letterSpacing:3,color:C.cyan,marginBottom:4}}>{TUT[tutStep].lbl}</div><div style={{...orb,fontSize:16,fontWeight:700,color:"#fff",letterSpacing:2,marginBottom:10,lineHeight:1.3}}>{TUT[tutStep].title}</div><div style={{fontSize:13,color:C.text2,lineHeight:1.75,marginBottom:20}}>{TUT[tutStep].body}</div>
        <div style={{display:"flex",gap:8}}>{tutStep<TUT.length-1?<><button onClick={finishTut} style={{background:"transparent",border:`1px solid ${C.border2}`,color:C.text3,padding:"10px 14px",...orb,fontSize:9,letterSpacing:2,cursor:"pointer",outline:"none"}}>SKIP</button><button onClick={()=>setTutStep(t=>t+1)} style={{flex:1,background:C.cyan,color:C.bg,border:"none",padding:10,...orb,fontSize:9,fontWeight:700,letterSpacing:2,cursor:"pointer",outline:"none"}}>NEXT →</button></>:<button onClick={finishTut} style={{flex:1,background:C.cyan,color:C.bg,border:"none",padding:10,...orb,fontSize:9,fontWeight:700,letterSpacing:2,cursor:"pointer",outline:"none"}}>BEGIN PROTOCOL →</button>}</div></div>
        <div style={{display:"flex",gap:5,justifyContent:"center",padding:12,borderTop:`1px solid ${C.border2}`}}>{TUT.map((_,i)=><div key={i} style={{width:5,height:5,borderRadius:"50%",background:i===tutStep?C.cyan:C.border,transition:"all .3s"}}/>)}</div>
      </div>
    </div>)}
    {modal&&(<div style={{position:"fixed",inset:0,background:"rgba(4,7,15,0.88)",backdropFilter:"blur(6px)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",padding:20}} onClick={e=>{if(e.target===e.currentTarget)setModal(false);}}>
      <div style={{background:C.bg2,border:`1px solid ${C.border}`,width:"100%",maxWidth:420,padding:22,position:"relative"}}>
        <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,${C.cyan},${C.purple})`}}/>
        <div style={{...orb,fontSize:11,fontWeight:700,letterSpacing:3,color:C.cyan,marginBottom:16}}>// NEW DIRECTIVE</div>
        <div style={{marginBottom:12}}><label style={{...mono,fontSize:8,letterSpacing:2,color:C.text3,display:"block",marginBottom:5}}>DIRECTIVE NAME</label><input autoFocus value={nh.name} onChange={e=>setNh(p=>({...p,name:e.target.value}))} onKeyDown={e=>e.key==="Enter"&&addHabit()} placeholder="e.g. Make my bed, Read 30 min..." maxLength={60} style={{...inpS}}/></div>
        <div style={{marginBottom:12}}><label style={{...mono,fontSize:8,letterSpacing:2,color:C.text3,display:"block",marginBottom:5}}>CATEGORY</label><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>{[["fitness","⚡","FITNESS"],["finance","◈","FINANCE"],["learning","◉","LEARNING"],["mindset","✦","MINDSET"],["relations","♡","RELATIONS"]].map(([cat,ico,lbl])=>{const active=nh.category===cat,col=catColor(cat);return(<button key={cat} onClick={()=>setNh(p=>({...p,category:cat}))} style={{border:`1px solid ${active?col:C.border2}`,padding:"8px",cursor:"pointer",textAlign:"center",...mono,fontSize:8,letterSpacing:2,color:active?col:C.text3,background:active?`${col}18`:"transparent",outline:"none"}}><span style={{fontSize:14,display:"block",marginBottom:3}}>{ico}</span>{lbl}</button>);})}</div></div>
        <div style={{marginBottom:12}}><label style={{...mono,fontSize:8,letterSpacing:2,color:C.text3,display:"block",marginBottom:5}}>XP REWARD — daily habits: 3-10 XP</label><input type="range" min="2" max="20" step="1" value={nh.xp} onChange={e=>setNh(p=>({...p,xp:parseInt(e.target.value)}))} style={{width:"100%",accentColor:C.cyan}}/><div style={{...orb,fontSize:13,color:C.cyan,textAlign:"center",marginTop:3}}>{nh.xp} XP</div></div>
        <div style={{display:"flex",gap:8,marginTop:16}}><button onClick={()=>setModal(false)} style={{background:"transparent",color:C.text3,border:`1px solid ${C.border2}`,padding:"9px 13px",...mono,fontSize:8,letterSpacing:2,cursor:"pointer",outline:"none"}}>CANCEL</button><button onClick={addHabit} style={{flex:1,background:C.cyan,color:C.bg,border:"none",padding:9,...orb,fontSize:9,fontWeight:700,letterSpacing:2,cursor:"pointer",outline:"none"}}>DEPLOY DIRECTIVE</button></div>
      </div>
    </div>)}
    {toast&&(<div style={{position:"fixed",top:62,left:"50%",transform:"translateX(-50%)",background:C.bg2,border:`1px solid ${C.cyan}`,boxShadow:`0 0 28px rgba(0,210,255,0.2)`,padding:"10px 20px",zIndex:300,textAlign:"center",whiteSpace:"nowrap",animation:"toastin .4s cubic-bezier(.16,1,.3,1)"}}><div style={{...orb,fontSize:11,fontWeight:700,color:C.cyan,letterSpacing:3,marginBottom:2}}>{toast.title}</div><div style={{...mono,fontSize:9,color:C.text2,letterSpacing:1}}>{toast.sub}</div></div>)}
    {xpPop&&(<div style={{position:"fixed",top:"45%",left:"50%",...orb,fontSize:22,fontWeight:700,color:C.green,textShadow:`0 0 14px rgba(0,255,136,.5)`,zIndex:300,pointerEvents:"none",animation:"xpfloat 1.2s ease forwards",letterSpacing:3}}>XP+</div>)}
  </div>);
}
